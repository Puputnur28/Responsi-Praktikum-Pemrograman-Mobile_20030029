package com.example.volumedankelilingbola;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText inputJariJari;
    Button btnHitung;
    TextView hasilVolume, hasilKeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputJariJari = findViewById(R.id.input_jari_jari);
        btnHitung = findViewById(R.id.btn_hitung);
        hasilVolume = findViewById(R.id.hasil_volume);
        hasilKeliling = findViewById(R.id.hasil_keliling);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double jariJari = Double.parseDouble(inputJariJari.getText().toString());
                double phi = 3.14;

                double volume = (4.0 / 3.0) * phi * jariJari * jariJari * jariJari;
                double keliling = 2 * phi * jariJari;

                hasilVolume.setText("Volume Bola: " + String.valueOf(volume));
                hasilKeliling.setText("Keliling Bola: " + String.valueOf(keliling));
            }
        });
    }
}
